/* مَدى — site logic (unchanged from the original single-file version) */
"use strict";
"use strict";
/* ---------- helpers ---------- */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"" ).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const nrm=s=>String(s||"").replace(/[\u064B-\u0652\u0640]/g,"").replace(/[أإآ]/g,"ا").replace(/\s+/g," ").trim();
const digits=s=>String(s||"").replace(/\D/g,"");
const hash=s=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return String(h>>>0)};
const isOwnerLogin=(name,code)=>{const n=nrm(name).replace(/ى/g,"ي");return (n==="مدي"||n.toLowerCase()==="mada")&&code.trim().toUpperCase()==="2026MH"};
const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
const MONTHS_AR=["كانون الثاني","شباط","آذار","نيسان","أيار","حزيران","تموز","آب","أيلول","تشرين الأول","تشرين الثاني","كانون الأول"];
const MONTHS_EN=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const fmt=(ts,lang)=>{const d=new Date(ts);return lang==="ar"?`${d.getDate()} ${MONTHS_AR[d.getMonth()]}`:`${d.getDate()} ${MONTHS_EN[d.getMonth()]}`};
const kindKey=k=>k==="vol"?"kindVol":k==="grant"?"kindGrant":"kindWs";
const ic={
 bell:'<svg viewBox="0 0 24 24"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
 user:'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg>',
 home:'<svg viewBox="0 0 24 24"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>',
 grid:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/></svg>',
 chat:'<svg viewBox="0 0 24 24"><path d="M21 12a8 8 0 0 1-8 8H4l2.5-2.5A8 8 0 1 1 21 12z"/></svg>',
 search:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
 clock:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
 dash:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="5" rx="2"/><rect x="13" y="10" width="8" height="11" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/></svg>',
 pin:'<svg viewBox="0 0 24 24"><path d="M12 17v5"/><path d="M9 10.8V4h6v6.8l2.5 3.2H6.5z"/></svg>',
 cal:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/></svg>',
 screen:'<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>',
 users:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.3 2.9-5 6.5-5s6.5 1.7 6.5 5"/><circle cx="17.5" cy="9" r="2.6"/><path d="M17 15.2c2.8.3 4.5 1.9 4.5 4.3"/></svg>',
 cap:'<svg viewBox="0 0 24 24"><path d="M2 9.5 12 5l10 4.5-10 4.5z"/><path d="M6.5 11.7V16c0 1.2 2.5 2.5 5.5 2.5s5.5-1.3 5.5-2.5v-4.3"/></svg>',
 share:'<svg viewBox="0 0 24 24"><circle cx="6" cy="12" r="2.5"/><circle cx="17" cy="5.5" r="2.5"/><circle cx="17" cy="18.5" r="2.5"/><path d="m8.3 10.8 6.4-4M8.3 13.2l6.4 4"/></svg>',
 place:'<svg viewBox="0 0 24 24"><path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>'
};
const LOGO="data:image/webp;base64,UklGRgASAABXRUJQVlA4IPQRAADwdwCdASrgAeABPmEwlkgkIyIhIVHIuIAMCWlu4XaxAXrD2W31cWf08/q/a9/fPyu/rna6+Uvb7OI/bD8//Yf3S+RXZL8lP6X1Bfxj+Nf4/8tOAr03zAvaT6V/0P796230v+A9APEA/LrjaPSPYD/R368e7T/Of/D/Tfl57RPzX/E/+z/RfAP/Mv69/yv7n7Ynru/an//+6R+0P///8IZCzdJGPEaSMeI0kY8RpIx4jSRjxGkjHiNJGPEaSMeI0kY8RpIx4jSRjxGkjHiNJGPEaSMe0683SRjxGmE+QGxAPsqIh9iaSMeI0kY8RpIx4jSRjxGkjJqK92ihkrfQpiNHVQ/EaJ2XfGFjt3pdHX0NbYHXLRa8OWxTLqYYycAoB9iaO8ceIebNtC0xjLfhVY9vK/oWI2+fYmkoA/cHushYapbePATEX+Efdqo7PZSMvlAFlBfRZvLBLX77s7DmroRlzNNdEKCsMSb0bZQ0H1MTsk0Kq1L9TSwVncfUB5axjxGkeBGjImVkDQWKeXaq+PYxHJu2v94o5AA1u+B2QVf+ij3MUwroJ6R/agO3ZgFb0ty6cucKE7KyRGlivwtPDOGm/0Iw4ASRev2itErFOZ8O5aZmBukjI9+VR9RqyH5hqa9RItGDGk+kml37iJsd0hQBrVq2G1XKcuN+bESJmIZmAXUuBW3E2ZoVQ0M7eLwk9PEK38c2ySUOUHG1Sz/UUKR7s3PGhR7U5VMR5mS8YF50nFM9U2aB+FC4FcNsjYIrNYg8D94v8x4E0S//pvsVzxHr5rG2Tl0oDwtVEsl8KKDqc6AhyBr2LFM+H6kdLWMel0vkjAfD2eUHl2IFtZXnJL4kjXa9pJc1vtLVtp75IsDoQ+q11EQPMWuiItf3/uV9sClFRhuQuWoGUR+XFp8ls3vQJ2kpSaxsvEGYw0FttbxKRBHC7onSGphqdK3yDml54RlGJNSnP3yKPjVXn2hBkoqQgqxEtHvkK4M1eQ3oLMbUVrqAe/UjxIZ/e/D9VRba2S+dbQ02mfAtTPH1BZPyM6WvA699B6sOPJ2mOf01ihP9BvT9R+jQ4ZMvcPEQ6T9vae0lYhs3wIE6JgIONKvmznbgLC4H/FpNKlDNoe4PVu5x2qd992+feEKZiRd9HfpAuUdy+GRCC2/XIFJf2rz7qVvjy8w5JwWn0jz9BuIB9iaSMmox4jSRizqzx9xWoSA3MyeJkVT83SvMtc3kE8H+phN4lID0vsmHa8cAI0dR5Xm5j3t3TZxzJtYx4jSRjxjYDi6SMeI0lZYjwAD+/9cC5cfshgAAAAAAAEeaHKAAAAR/ceLONbYAzjoKKVDculivmsT8eJQ1XUDK+BpA/RkR20OkMQkxxtgc9vfHRzcjouQADijKHuV4luyIpaSdqIcXcQMn68NyG+s4xk+k5/rlblGM2rSeSVE8jkOty9hOxYMhbssBx+2FJj46XSt1mq+u5tilDUmNNF+qVGX0OoTkygX7ivybQinl3vJVIXtDxg7GHcCzfZdNuplvucGp3ImtbLEeYmKvuf2sZ6a48m8aQELcOU2egRyNkZH3cVYffmgI9InDJuIESGz9BfMzQI552IsSilCcU4/lrKj7F0bwHYvZxTl7nG9yKcLRE9cQEllkHuvbk1bIW4DUAqOQpkR4tCENCOnwBIZbm4Q8lszjuelAxDZuQ1euFfvm0P+LZ8gfVTgGoT1wJq1NxMIv3MuRl6XjUTktBfzpXQb+wmnri/1Wr20QFNu/YgabNFiQM3nkXogBz5sbCupPvdhfxcrWrSA2qvqFPXpex12AP23Z3RLbVpx6rhqb9xXrOAbuke24+3v2/BVW7qoG4yjB4JAVc5Y8MweVDeiwXhWL5QwBynSIhcMO5Kid6ggoa/5e+G9iOpWmJ+4P35TDGjGhCf9odHuCbnvcu4D3dyedY6CGmGMnrVj/pU/9WdSqDygMnRcysNs5OHDy9iIGKNaTgvk2cm8/phgnnB7Dw2+ftr4WRMv/WR4vMYw6EM65Ms9AyxoT8KqtjszabG+4LWXlX556e252aioLyE6/B8vju6c3zYWR3YGEEAU/fg/brzRuM1pNoROklO+zz5KXXb6B9jtuN0SC5QjOwJYdd+bk41UtuGpCQ6/8bD6UuJ5hzIneIIdi1Cub9GPgwOQS+46cKEsYx4NpXASk1je1D/X3aqiisgjzu8azpBY6j9K5U9KOtlSJFGE+tAx0EFgU2KM3jtTpfW7SWoTSnUTHi/cuABWpmNnkLagjBp19LtxItKrvGd+Qx8pca9Je5K5UaWCNey6665gqnMG0+DszQ+q/UUTaMgCQVQrvb9BxRy7Pa7gIyP18j/0lk2Y0W31Ig4Ekwn+xigZcVBMsTHWIcf5WFnXcZ1/jJHsWiQY2V4LWjYsKC0+avUU6TkA4sAM2gRm+f3UTt7zoJbsAiKLly3Zauto+qcguBkiBCFao2KyoHLCUU+fAiU8JEGoOcg1VLh3YGIKEa7PkgYNGfEHKtBwhZNVmRFRRbuW+3lsH2lZboE+sdaX8tHzCwiIJkc7ypZC8ggpWJqOqlM6cqUUgZYTwtdSNlDyERCn7xjIClJwONBQsQkKyYL3U5PbENGyYUXRO8ExfPiG1z0iAgqqj2u73ZXwTuPPMFFwbdS3ch+9Cq3zdzlsSCNa99qhltVeF789RYKmdoNjE+CLoXy6sDnRmGOUtFW366tKp+0gHfgxvkadNmrxXWWouV8RzPyTLEy0P8k9uT9crncSq8iWeSENXWn7twMHQGPfxu8So7GUrZth17RcbQuwRF+/xtngNUpZIgDnP/9QU/3CFeUpKTXjaR2z/ZeSh2+syu8bPkxf5PMzISxQg0EBFVqdvndVc24t0o7akbM7pdDASG7+V4AK/c+0KQoldyiMPlTEn35oaii9KmJUovQNd3/l4wX9mGLu86KC9Pg+O36bATTHHWiu4GNMnF/JMgoOY/X1gVC/VyFNtPikwG9HS8t3bTJIsYyKBzinPhCUpY3Gmz73/zVlDv/WdaSibvhxo/gF7TePUhw/4Hq3Plqok01IN6GNQnTkvGesYaMUELWZyyjX51h0KadtNNXDe7MjmNJHe34q+vDrdBQNH/R8OK9BLY7hDG662mFEaSV8yBN4Dr+JjR3qSvr7Otha74eLpvc6YRG3vv5oPuVX2t0kcxJ4mjheBJeWClcOTHNu30DjLjDo2r4zHgSkxjy+mycZbs6n8cTWJg/Sp8xtQd9AYyz4hbfx+Gd3xJGrCTkr45q7HKm2w4AnHK7nC+77y8CSdivgBN3/bwqh7YlBBPmhwO9x/FEaza/3A9rUB4Lz0BiRdgmdwHP1Bidcsu34cqvXtiBBPBtxnezz3pnhhxmvEvrkVq+hKnELRfT6rk/QNGeP2P9QsdO6HnQ7uHRlkNKKKV/Z5PONf+u5Mu1JO009Yxygcdae5LQnUfz7LkYiFihgv/Bg4AId4S1oymvqmsz1w41M+kucr2BB/G4KJnhyuYBg9pyy6p1UR9z0BZhkHb1/fM0P+ambI63jtB/AOA+17dEp0jZxGdY2ngnBUMKgcZhbjaqvynfWydubTfJ2Y/Yj8ZqsLxop/DHWNoSCNlF82C17b03ve1spnxFJlR9C97kSSUV0f3p5XW8XnPNnVyPRU020WyyzZScV1X9S1D6hOAs6n3ZgkEVw8+EejggjGlEa0dWMxWeTuhNq1tmTGjlgGYEYaK4lGTRxQ8oilrSVvZZiaT/qv3yC/okolerK6iTtJ1rDp0couYDDSOjCKME5UtwBVkvO7FKHCWq8OxueDhl3qvmr28ht/hDfYaP+tgAPbhiyy7iIyGbuKFqnMPhZCOaFKBbtqc8P1+CreafRnzu0swRRlHvMHM2bzeqC+9/uBPo4wDImjeQEA8XkCkxrupJDV75grKY2L/ApuZ53UJqGxP2dFtV9gqbdblocSG6B7FV9kJTqaoDizXbrMsVUSYAABPHD9CfZzND3B8KetgvxIJmHZgSytdWo1UnCp10j1n6giB+72q1ycrKUaaND8W6ZVSUVRaA3k7hNnMO8cm0JHQqOznKWXa9+CJtxLiQEkvLOc0KVrvP2leFSHX/R4FhvCdrTZQe8TXcyi/toIKuWxk27Fuh0mu/TL1Op5GgCowfCdSF7yUCFQuiwScB7Sn/LYi9ahV5xtoZ7S7fXich+vHU1kgMSUetdY0WtK6W52ZqO+Vqb624e4lQimY8RbRUFUaK84cmci3HkggDhiiITjuJ0CyK3N/o/Eux3FBFE8DsCskM2Db+eoWcK3fhn13+N+A8yE+OTJiBLC4ahX0qAzw22r+diWGZwW/f00Q2555hwm0m5U2WIZFiKCUWnaJtTHy1Hr/RKSun08ObsRZgGQndVhq/ax4bcpwVz/4n3/onulhUdbrxE083XShee4otiuImWlalX+0znlMG+ZeQMUqNIDkGbtwvKGUzyd3bSNMqtRWpOQZkry2zIkA9kXt+wuxJ9Iq8+uCHxeGZX/FaSuavmCuenL8hoTwBVlmCHq2DbU6WhUOfCawEvSjd9/pjvyBwYwa9cFZ149Xebe+IFUyygnyoe775knBv9PTADhLQazMQiLPOx7ju3RLaVIWgTyjMc8XXrTm+vQL1jMHfX2TZkmqpPHJiotPThRa8LLdo6B3v4aIJuIi6OxUPRMbee7Vuge10+r3E0xZ1HVysO//QAQb2l9hD/7XLmaFNBpsKq/ot7vE4EH3mmUgFcFHme6kf6f8vB24/xJgFQQc57T77tlwB/yE2W5RaYLwOePyEXpIX4ji2O5oXh3212sy5mgcYc141I/LRvfP2IWWegUkU+hpslvUxKt2n29mOY52U/nVrlUDD9Qv4r+tXRKkQWqILcbOH8ZXw0gS0J7xrFdDylgvpHdF6Fg+NMkMfoGbEM7Isx6GXSxPgGaQdLYeD9UxhgJGB/+Lc8n5E9FmmLU6GgY66wOchXS6cOaZzJ4j4R57m7JLUgVkNuOJiQZJG/aj4hzs5OQljMWC8XVkbKcssAjch5ZD0HTQUivMwusQMc0elH5KxaGgaAKfd2CgIMZ9fM/xlcKpeBaSkOUN3imPUngy0W8BxcaUaJ+VAw/10b3qay0KWZm+yKXNFb47435bKEzdtkuGYzWQNUAT7EEpFAZ86MCIfpRI4hZk3XNzPJWz53qKav+QUwZ8jjKuKbUVHLBhydgrX58iTAm7avi4Ty+ZlKIcsi94wqv49//NEu8UYHNphSrfvKdbN6Jw/sIe6TqXhk+glLI5MvsxxJBeesdMPDU6NEo5gyzWIjyf29eMAzr4Syw9NMwJJGRLytji8O2P5njw93nz5LgSzmQxVDNM4DLyNiX7rXDGWMc6aBfAMogNSoFTsjMyrWoE+PQFOG/QrK7E1uuvE2lqw2ZeYB7cKKGlREARO2u7agChzvOcGZrgE/aNt9y8TTMEGc3ENGgW566ateOCvxwyn/wkfiWP8rVQnEFA0lkyWIYhvmAEg46IHOS/Wx+JUnf4kGAedvkIhnKSJAOfvUE1W4rV8h/L1n2L9wyzd2COyz7dlNENKQo6xrP/oHCmBc067dxW9rXCNwFUv+wuXVl5CjKuYpyBxeSDN+V902F64dreeKMyvwciynOMd0H4jlK8MivDoQtADc8ho7WHs0na3D9Ir0l+MLKT8LEwG0oj4zitzAUTIVNnud+C1Oa0TBRxSyjIXcU9iAu4pQ44Bo8vFCotzBR+6iHnfBkfY6vU0p/z5syi/jJ7YkW2n+tXSddF+JWNwyaz1oBoUPkkmkCFGBraiZ3r2fWai5I6nN8sxAZLY1uo4cuqRUQPMcRk3ldLs5UzPHVW1ae3FQvUZFnn8i9zyRXfkDzaVSAqm/3WXbUhnaKhW3jenxTs7izKH/GPbXewP8YSBmiCiB4OrDBAYpxYr8JTrWVskab8UT+wDb4jIpgCccf37ex33vffyKoPKBjIKHxbF9r2/ivxXuLsRdOEYKXTO+Rknm5/DK6uKw4GVus1184bs3oL+L7vqR0sTe5tsa3dt6X7gOF71i1cjg6/NU/NtE/Rc+Y4t++To2n7nOpbJE21laXdzUITDafaAbSh1aivDAAwjgwzmAcAC9OACjMACHKEIWLKAAAAAA=";
/* ---------- state ---------- */
const DEFAULT_SETTINGS={token:"8866352840:AAGdGPx8tywcuslsRh8GGVpnnJj1A5o6EBs",chatId:"",channel:"https://t.me/m_a_d_a3",tiktok:"https://www.tiktok.com/@m_a_d_a3",lang:"ar",showAnn:true};
const SEED_OPPS=[
 {id:"seed-ws-1",type:"ws",title:"ورشة: صناعة فيديو قصير للسوشيال",tagline:"من الفكرة للمونتاج في جلسة واحدة",about:"ورشة تطبيقية تمشي وياك خطوة بخطوة: فكرة، سكربت، تصوير بالموبايل، ومونتاج بسيط. ما تحتاج خبرة سابقة، بس موبايل ووقت.",learn:["سكربت قصير يمسك الانتباه","لقطات واضحة بالموبايل","تصدير مناسب لتيك توك"],date:"12 تشرين الثاني",time:"6:00 مساءً",mode:"online",place:"أونلاين — رابط ينرسل بعد القبول",seats:"25",status:"open",published:true,dur:"يوم واحد",level:"beg",link:"",dl:"",cover:"",pin:true,qs:["ليش حاب تشارك بالورشة؟","عدك تجربة سابقة بالتصوير أو المونتاج؟"]},
 {id:"seed-vol-1",type:"vol",title:"تطوع: فريق تغطية فعاليات مَدى",tagline:"تصوير، تنظيم، ومساعدة الضيوف يوم الفعالية",about:"نبحث عن متطوعين يساعدون بالتغطية والنشر: تصوير جو الفعالية، تنظيم الدخول، ومساعدة الضيوف. الالتزام بالوقت شرط.",learn:["خبرة ميدانية","شهادة تطوع من مَدى","شغل مباشر ويا التيم"],date:"يُعلن قريباً",time:"",mode:"person",place:"بغداد",seats:"12",status:"soon",published:true,dur:"يوم الفعالية",level:"",link:"",dl:"",cover:"",pin:false,qs:["بأي مدينة تگدر تحضر؟","شنو تفضل: تصوير، تنظيم، لو استقبال؟"]},
 {id:"seed-grant-1",type:"grant",title:"منحة مهارات رقمية — مسار الويب",tagline:"مقعد مدعوم لمسار عملي بواجهات الويب",about:"مقعد مدعوم لمسار عملي. الأولوية للي يلتزم بالحضور ويسلّم المشروع النهائي. ما ننشر مقعد بلا متابعة.",learn:["أساسيات واجهة الويب","مشروع تتخرج بيه","متابعة من التيم"],date:"التقديم مفتوح",time:"",mode:"hybrid",place:"أونلاين + لقاء حضوري ختامي",seats:"0",status:"open",published:true,dur:"4 أسابيع",level:"mid",link:"",dl:"",cover:"",pin:false,qs:["شنو مستواك الحالي بالبرمجة؟","قدّه تلتزم أسبوعياً؟"]}
];
const SEED_NEWS=[{id:"seed-news-1",title:"باب الانضمام لتيم مَدى مفتوح",text:"إذا عندك مهارة برمجة، تصميم، كتابة، لغات، أو نشر الفرص — قدّم من قسم انضم للإدارة. الطلب يوصلنا على تيليجرام.",ts:1761600000000}];
const SEED_ANN=[{id:"seed-ann-1",text:"التقديم لإدارة مَدى مفتوح — برمجة، تصميم فيديو وصور، كتابة، لغات، ونشر الفرص",on:true,ts:1761600000000}];
const DB_KEY="mada-web-v1";
let DB;
try{DB=JSON.parse(localStorage.getItem(DB_KEY))||null}catch(e){DB=null}
if(!DB||!Array.isArray(DB.opps)){
 DB={opps:JSON.parse(JSON.stringify(SEED_OPPS)),apps:[],staff:[],news:JSON.parse(JSON.stringify(SEED_NEWS)),anns:JSON.parse(JSON.stringify(SEED_ANN)),support:[],users:[],session:null,settings:{...DEFAULT_SETTINGS},phone:"",seenCongrats:[],thread:[],seq:1000};
}
const save=()=>{try{localStorage.setItem(DB_KEY,JSON.stringify(DB))}catch(e){}};
save();
const nextUid=()=>{DB.seq=(DB.seq||1000)+1;return DB.seq};
/* ---------- i18n ---------- */
const T={
 ar:{heroT:"مَدى — تيم شبابي يفتح لك الطريق",heroP:"ورش، تطوعات، ومنح مختارة بعناية. نختصرلك الطريق: تدخل، تشوف الفرص، وتقدّم بضغطة.",ctaOpp:"فرص مَدى",ctaTeam:"انضم لإدارة مَدى",teamTitle:"تيم مَدى",teamP:"نشتغل بأقسام واضحة، كل قسم يدعم الباقي:",staffTitle:"تطوع بالإدارة",staffP:"عدك مهارة ووقت؟ عبّي الطلب ويوصلنا مباشرة.",staffBtn:"قدّم طلبك",lookupT:"تحقق من حالة طلبك",lookupP:"حط رقم هاتفك (نفس اللي قدّمت بيه) ونوريك وين وصل طلبك.",lookupBtn:"شيك",askTitle:"اسأل مساعد مَدى",askP:"بوت ذكي يجاوبك عن الفرص المنشورة هسه، بالعربي أو بالإنجليزي.",askBtn:"ابدأ المحادثة",newsT:"آخر أخبار مَدى",newsAll:"الكل",supT:"محتاج مساعدة؟",supP:"واجهت مشكلة بالتقديم أو عندك سؤال؟ راسلنا مباشرة.",supBtn:"تواصل مع الدعم",aboutT:"عن مَدى",aboutP:"مَدى تيم شبابي عراقي يفتح مجالات أمام الشباب: ورش تطويرية، فرص تطوع، ومنح تعليمية. ننشر الفرص أول بأول على قناتنا وعلى الموقع.",tabHome:"الرئيسية",tabOpp:"الفرص",tabAsk:"اسأل",tabMe:"حسابي",kindWs:"ورشة",kindVol:"تطوع",kindGrant:"منحة",open:"مفتوح",soon:"قريباً",closed:"مغلق",modeOnline:"أونلاين",modePerson:"حضوري",modeHybrid:"مختلط",lvlBeg:"مبتدئ",lvlMid:"متوسط",lvlAdv:"متقدم",all:"الكل",published:"منشور",draft:"مسودة",pin:"مثبّت",searchPh:"ابحث عن فرصة…",noOpps:"ماكو فرص بهاي التصفية",noOppsP:"جرب تغيّر البحث أو النوع، وتابع القناة لأول إعلان.",date:"التاريخ",time:"الوقت",mode:"النمط",place:"المكان",seats:"المقاعد",dur:"المدة",level:"المستوى",unlimited:"غير محدود",aboutOpp:"عن الفرصة",learn:"شنو تستفيد؟",apply:"قدّم",externalApply:"تقديم عبر الرابط",ctaT:"التقديم",ctaHead:"قدّم خلال دقيقة",ctaHint:"طلبك يوصل لإدارة مَدى مباشرة، ونرد عليك بأسرع وقت.",ctaBtn:"تقديم على الفرصة",share:"مشاركة",closesIn:"التقديم ينغلق بعد",dayUnit:"يوم",lastDay:"آخر يوم للتقديم!",dlOver:"انتهى موعد التقديم",qsTitle:"أسئلة التقديم",fName:"الاسم",fNamePh:"اسمك الكامل",fPhone:"رقم الهاتف",fTg:"يوزر تيليجرام",fSend:"أرسل التقديم",fSending:"جاري الإرسال…",fNote:"توجّهاتك تسجّل بالإدارة وتوصلنا على تيليجرام.",required:"هذا الحقل مطلوب",needFields:"عبّي الحقول المطلوبة",okSent:"وصلنا طلبك! نرد عليك قريباً.",okLocal:"سجلنا طلبك محلياً (تعذر الوصول لتيليجرام).",okSup:"وصلت رسالتك للدعم!",login:"تسجيل الدخول",logTab:"دخول",regTab:"حساب جديد",uName:"الاسم",uCode:"الرمز",uCode2:"تأكيد الرمز",uCreate:"أنشئ الحساب",uEnter:"دخول",welcome:"أهلاً",errShort:"الرمز 4 خانات على الأقل",errMatch:"الرمزين ما يتطابقون",errExists:"الاسم مستخدم، اختار ثاني",errReserved:"هاي الاسم محجوز",errNoUser:"ماكو حساب بهاي الاسم",errCode:"الرمز غلط",meTitle:"حسابي",meLoginT:"ادخل بحسابك",meLoginSub:"سجّل حتى تتابع طلباتك وتستفيد من كل الميزات.",meJoin:"دخول / حساب جديد",meAdmin:"لوحة الإدارة",meLang:"اللغة",langName:"English",logout:"خروج",loggedOut:"سجلت خروج",admin:"أدمن",bell:"الأخبار والإشعارات",bellEmpty:"لا كو أخبار جديدة",close:"إغلاق",congratsTitle:"🎉 الف مبروك!",congratsOk:"حلو",supName:"الاسم",supContact:"طريقة التواصل (اختياري)",supMsg:"رسالتك",supSend:"إرسال",applyStaff:"طلب انضمام للإدارة",staffName:"الاسم الثلاثي",staffAge:"العمر (14-70)",staffPhone:"رقم الهاتف",staffTg:"يوزر تيليجرام",rolesTitle:"اختار القسم (تگدر أكثر من واحد)",staffIdea:"اقتراحك لتطوير التيم",staffIdeaPh:"شنو تضيف لمَدى؟",staffSend:"أرسل الطلب",staffNeedName:"اكتب اسمك الثلاثي",staffNeedAge:"العمر لازم بين 14 و 70",staffNeedPhone:"رقم الهاتف قصير",staffNeedTg:"يوزر تيليجرام غير صالح",staffNeedRole:"اختار قسم واحد على الأقل",staffNeedIdea:"اكتب اقتراح أطول شوية",statusNew:"بالانتظار",statusAccepted:"مقبول",statusRejected:"مرفوض",staffStatusT:"حالة طلبك",staffNoFound:"ما لقينا طلب بهاي الرقم",roles:{code:"برمجة",video:"تصميم فيديو",photo:"تصميم صور",copy:"كتابة إعلانات",lang:"لغات",publish:"نشر الفرص"},roleHints:{code:"تطوير الموقع والأدوات",video:"مونتاج وموشن",photo:"تصميم جرافيك",copy:"محتوى ونصوص",lang:"ترجمة وكتابة بلغات",publish:"متابعة القنوات ونشر الفرص"},suggests:["شنو الفرص المفتوحة هسه؟","شلون أقدّم للورش؟","كيف انضم لإدارة مَدى؟","اكو منح متاحة؟"],askPh:"اكتب سؤالك…",askSend:"إرسال",askHello:"هلا! أنا مساعد مَدى. اسألني عن الورش، التطوعات، المنح، أو طريقة التقديم.",askSrc:"من فرص الموقع",dashT:"لوحة الإدارة",dashStaff:"طلبات الإدارة",dashOpps:"الفرص",dashApps:"التقديمات",dashNews:"الأخبار",dashAnns:"الإعلانات",dashSup:"الدعم",dashSet:"الإعدادات",noStaff:"لا طلبات بعد",noApps:"لا تقديمات بعد",noNews:"لا أخبار بعد",noSup:"لا رسائل بعد",noAnns:"لا إعلانات بعد",accept:"قبول",reject:"رفض",confirmAccept:"متأكد من القبول؟ ما تنكشف مرات ثانية.",acceptedDone:"قبضنا بنجاح — الأهل يشف ملخص القبول",newsTitlePh:"عنوان الخبر",newsTextPh:"نص الخبر",add:"إضافة",annPh:"نص الإعلان المتحرك",show:"إظهار",hide:"إخفاء",del:"حذف",saveSet:"حفظ الإعدادات",sToken:"توكن البوت",sChat:"معرّف المحادثة (Chat ID)",sCh:"رابط القناة",sTt:"رابط تيك توك",setNote:"البوت يوصل طلبات التقديم والدعم لمحادثة تيليجرام. حط التوكن والمعرّف حتى يشتغل الإرسال.",test:"رسالة تجريبية",testOk:"وصلت التجريبية ✅",testFail:"ما وصلت — تحقق من التوكن والمعرّف",copied:"نُسخ",wTitle:"العنوان",wTagline:"وصف سطر واحد",wAbout:"التفاصيل",wLearn:"الفوائد (سطر لكل فايدة)",wDate:"التاريخ",wTime:"الوقت",wPlace:"المكان",wSeats:"المقاعد (اتركه فارغ أو 0 = غير محدود)",wDur:"المدة",wLink:"رابط تقديم خارجي (اختياري)",wDl:"موعد آخر تقديم (اختياري)",wCover:"رابط صورة الغلاف (اختياري)",wQs:"أسئلة التقديم (سطر لكل سؤال)",wPub:"منشور",wPin:"تثبيت بالأعلى",wType:"النوع",wMode:"النمط",wStatus:"الحالة",wLevel:"المستوى",addOpp:"فرصة جديدة",editOpp:"تعديل الفرصة",save:"حفظ",cancel:"إلغاء",oppAdded:"انضافت الفرصة",oppSaved:"حفظت التعديلات",delQ:"متأكد من الحذف؟",appsOf:"تقديمات",viewApps:"شوف التقديمات",sentTo:"أُرسلت لتيليجرام",byYou:"طلبك",copyMsg:"نسخ نص القبول",copyOk:"نُسخ نص القبول",phoneLookup:"تحقق بوهاتفك",joinDate:"بالانضمام من",emptyDash:"فاضي هسه",del2:"حذف",yes:"نعم",no:"إلغاء"},
 en:{heroT:"Mada — a youth team that opens doors",heroP:"Hand-picked workshops, volunteering and scholarships. Enter, browse, apply in one tap.",ctaOpp:"Mada opportunities",ctaTeam:"Join the Mada team",teamTitle:"The Mada team",teamP:"We work in clear sections, each supporting the other:",staffTitle:"Volunteer with us",staffP:"Got a skill and time? Send your application — it reaches us directly.",staffBtn:"Apply",lookupT:"Check your application",lookupP:"Enter the phone number you applied with and we'll show your status.",lookupBtn:"Check",askTitle:"Ask the Mada assistant",askP:"A smart bot answering about published opportunities, in Arabic or English.",askBtn:"Start chatting",newsT:"Latest from Mada",newsAll:"All",supT:"Need help?",supP:"Stuck applying or have a question? Message us directly.",supBtn:"Contact support",aboutT:"About Mada",aboutP:"Mada is an Iraqi youth team opening doors: development workshops, volunteering and scholarships. New opportunities land on our channel and this site first.",tabHome:"Home",tabOpp:"Opportunities",tabAsk:"Ask",tabMe:"Me",kindWs:"Workshop",kindVol:"Volunteering",kindGrant:"Scholarship",open:"Open",soon:"Soon",closed:"Closed",modeOnline:"Online",modePerson:"In person",modeHybrid:"Hybrid",lvlBeg:"Beginner",lvlMid:"Intermediate",lvlAdv:"Advanced",all:"All",published:"Published",draft:"Draft",pin:"Pinned",searchPh:"Search opportunities…",noOpps:"No opportunities match this filter",noOppsP:"Try changing the search or kind, and follow the channel for first announcements.",date:"Date",time:"Time",mode:"Mode",place:"Place",seats:"Seats",dur:"Duration",level:"Level",unlimited:"Unlimited",aboutOpp:"About this opportunity",learn:"What you gain",apply:"Apply",externalApply:"Apply via link",ctaT:"Apply",ctaHead:"Apply in a minute",ctaHint:"Your application reaches the Mada team directly, and we reply as soon as we can.",ctaBtn:"Apply for this",share:"Share",closesIn:"Applications close in",dayUnit:"day(s)",lastDay:"Last day to apply!",dlOver:"Applications closed",qsTitle:"Application questions",fName:"Name",fNamePh:"Your full name",fPhone:"Phone number",fTg:"Telegram username",fSend:"Send application",fSending:"Sending…",fNote:"Your answers go to the admin panel and our Telegram.",required:"This field is required",needFields:"Fill the required fields",okSent:"Application received! We'll get back soon.",okLocal:"Saved locally (couldn't reach Telegram).",okSup:"Your message reached support!",login:"Sign in",logTab:"Sign in",regTab:"New account",uName:"Name",uCode:"Passcode",uCode2:"Confirm passcode",uCreate:"Create account",uEnter:"Enter",welcome:"Welcome",errShort:"Passcode needs 4+ characters",errMatch:"Passcodes don't match",errExists:"Name taken, pick another",errReserved:"That name is reserved",errNoUser:"No account with that name",errCode:"Wrong passcode",meTitle:"My account",meLoginT:"Sign in",meLoginSub:"Sign in to track your applications and unlock everything.",meJoin:"Sign in / new account",meAdmin:"Admin panel",meLang:"Language",langName:"العربية",logout:"Sign out",loggedOut:"Signed out",admin:"Admin",bell:"News & notifications",bellEmpty:"No news yet",close:"Close",congratsTitle:"🎉 Congratulations!",congratsOk:"Great",supName:"Name",supContact:"Contact (optional)",supMsg:"Your message",supSend:"Send",applyStaff:"Team application",staffName:"Full name",staffAge:"Age (14-70)",staffPhone:"Phone number",staffTg:"Telegram username",rolesTitle:"Pick a section (multiple allowed)",staffIdea:"Your idea to improve the team",staffIdeaPh:"What would you add to Mada?",staffSend:"Send application",staffNeedName:"Write your full name",staffNeedAge:"Age must be 14-70",staffNeedPhone:"Phone number too short",staffNeedTg:"Invalid Telegram username",staffNeedRole:"Pick at least one section",staffNeedIdea:"Write a longer idea",statusNew:"Pending",statusAccepted:"Accepted",statusRejected:"Rejected",staffStatusT:"Your application status",staffNoFound:"No application with this number",roles:{code:"Code",video:"Video design",photo:"Photo design",copy:"Copywriting",lang:"Languages",publish:"Publishing"},roleHints:{code:"Site and tools",video:"Editing and motion",photo:"Graphic design",copy:"Content and copy",lang:"Translation",publish:"Channels and opportunities"},suggests:["What's open now?","How do I apply?","How do I join the team?","Any scholarships?"],askPh:"Type your question…",askSend:"Send",askHello:"Hi! I'm the Mada assistant. Ask me about workshops, volunteering, scholarships, or applying.",askSrc:"From site opportunities",dashT:"Admin panel",dashStaff:"Team applications",dashOpps:"Opportunities",dashApps:"Applications",dashNews:"News",dashAnns:"Announcements",dashSup:"Support",dashSet:"Settings",noStaff:"Nothing yet",noApps:"Nothing yet",noNews:"Nothing yet",noSup:"Nothing yet",noAnns:"Nothing yet",accept:"Accept",reject:"Reject",confirmAccept:"Sure about accepting? This can't repeat.",acceptedDone:"Accepted — the member sees the reply",newsTitlePh:"News title",newsTextPh:"News text",add:"Add",annPh:"Ticker announcement text",show:"Show",hide:"Hide",del:"Delete",saveSet:"Save settings",sToken:"Bot token",sChat:"Chat ID",sCh:"Channel link",sTt:"TikTok link",setNote:"The bot forwards applications and support messages to a Telegram chat. Set the token and ID to enable sending.",test:"Test message",testOk:"Test arrived ✅",testFail:"Didn't arrive — check token and ID",copied:"Copied",wTitle:"Title",wTagline:"One-line description",wAbout:"Details",wLearn:"Benefits (one per line)",wDate:"Date",wTime:"Time",wPlace:"Place",wSeats:"Seats (empty or 0 = unlimited)",wDur:"Duration",wLink:"External apply link (optional)",wDl:"Application deadline (optional)",wCover:"Cover image URL (optional)",wQs:"Application questions (one per line)",wPub:"Published",wPin:"Pin to top",wType:"Kind",wMode:"Mode",wStatus:"Status",wLevel:"Level",addOpp:"New opportunity",editOpp:"Edit opportunity",save:"Save",cancel:"Cancel",oppAdded:"Opportunity added",oppSaved:"Saved",delQ:"Delete for sure?",appsOf:"applications",viewApps:"View applications",sentTo:"Sent to Telegram",byYou:"your application",copyMsg:"Copy acceptance text",copyOk:"Copied",phoneLookup:"Check by phone",joinDate:"Joined",emptyDash:"Empty for now",del2:"Delete",yes:"Yes",no:"Cancel"}
};
const t=k=>T[DB.settings.lang][k]??T.ar[k]??k;
const L=()=>DB.settings.lang;
/* ---------- catalog & assistant ---------- */
function toCatalog(items){
 const lab={kindWs:t("kindWs"),kindVol:t("kindVol"),kindGrant:t("kindGrant"),open:t("open"),soon:t("soon"),closed:t("closed"),online:t("modeOnline"),person:t("modePerson"),hybrid:t("modeHybrid"),beg:t("lvlBeg"),mid:t("lvlMid"),adv:t("lvlAdv"),unlimited:t("unlimited")};
 return items.filter(i=>i.published).map(i=>({title:i.title,kind:lab[kindKey(i.type)]||i.type,status:lab[i.status]||i.status,date:i.date,time:i.time,mode:lab[i.mode]||i.mode,place:i.place,seats:i.seats&&i.seats!=="0"?i.seats:lab.unlimited,dur:i.dur,level:i.level?(lab[i.level]||i.level):"",tagline:i.tagline,about:i.about,learn:i.learn}));
}
function scoreText(q,item){
 const blob=nrm([item.title,item.kind,item.status,item.tagline,item.about,item.place,item.mode,item.learn.join(" ")].join(" "));
 const parts=q.split(" ").filter(w=>w.length>1);let s=0;
 for(const w of parts) if(blob.includes(w))s+=2;
 if(q.length>3&&blob.includes(q))s+=3;
 return s;
}
function answerFromCatalog(question,items,lang){
 const q=nrm(question).toLowerCase();
 if(!items.length)return lang==="ar"?"هسه ماكو فرص منشورة على مَدى. تابع القناة، والفرص الجديدة تنزل هناك أول.":"Nothing is published on Mada right now. Follow the channel — new opportunities land there first.";
 if(/ادار|تيم|فريق|انضم|توظيف|admin|team|join/.test(q))return lang==="ar"?"الانضمام لتيم مَدى من الرئيسية، قسم «انضم لإدارة مَدى». تعبّي الاسم الثلاثي، العمر، رقم الهاتف، يوزر تيليجرام، القسم، واقتراح لتطوير التيم. الطلب يوصل لوحة الإدارة وعلى تيليجرام.":"Join the Mada team from the home page, “Join the Mada team”. You'll add your full name, age, phone, Telegram, a section, and an idea. It reaches the admin panel and Telegram.";
 const wantsHow=/كيف|شلون|طريقة|اقدم|قدّم|تقديم|اسجل|apply|how/.test(q);
 let pool=items;
 if(/ورش|workshop/.test(q))pool=items.filter(i=>/ورش|workshop/i.test(i.kind));
 else if(/تطوع|volunteer/.test(q))pool=items.filter(i=>/تطوع|volunteer/i.test(i.kind));
 else if(/منح|منحه|scholarship|grant/.test(q))pool=items.filter(i=>/منح|scholarship|grant/i.test(i.kind));
 if(/مفتوح|open/.test(q))pool=pool.filter(i=>/مفتوح|open/i.test(i.status));
 if(/قريب|soon/.test(q))pool=pool.filter(i=>/قريب|soon/i.test(i.status));
 if(/مغلق|closed|مسكر/.test(q))pool=pool.filter(i=>/مغلق|closed/i.test(i.status));
 if(/اونلاين|أونلاين|online/.test(q))pool=pool.filter(i=>/اونلاين|online/i.test(i.mode));
 if(!pool.length)pool=items;
 const ranked=pool.map(i=>({i,s:scoreText(q,i)})).sort((a,b)=>b.s-a.s);
 const top=ranked.filter(x=>x.s>0).slice(0,3);
 const list=top.length?top.map(x=>x.i):pool.slice(0,4);
 const lines=list.map(i=>{const bits=[i.kind,i.status,i.date,i.mode,i.place].filter(Boolean).join(" · ");const gain=i.learn[0]?(lang==="ar"?` تستفيد: ${i.learn[0]}.`:` You gain: ${i.learn[0]}.`):"";return `• ${i.title} — ${bits}.${i.tagline?` ${i.tagline}.`:""}${gain}`});
 const head=wantsHow?(lang==="ar"?"التقديم من صفحة الفرصة نفسها داخل الموقع: تفتحها وتدوس «قدّم» إذا حالتها مفتوحة. إذا مكتوب قريباً أو مغلق، التقديم بعد ما انفتح. إذا الفرصة عدلهه رابط خارجي، الزر يوصلك للرابط.":"Apply from the opportunity page on the site: open it and tap Apply when the status is open. If it has an external link, the button takes you there."):(lang==="ar"?"من الفرص المنشورة هسه على مَدى:":"From the opportunities published on Mada:");
 return `${head}\n\n${lines.join("\n")}`;
}
/* ---------- telegram ---------- */
async function tgSend(token,chatId,text){
 try{
  const r=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:chatId,text:String(text).slice(0,3500)})});
  return r.ok;
 }catch(e){return false}
}
async function pushTelegram(text){
 const s=DB.settings;
 if(!s.token||!s.chatId)return{ok:false};
 return{ok:await tgSend(s.token,s.chatId,text)};
}
/* ---------- ui state ---------- */
let route=location.hash||"#/", adminTab="staff", editOppId=null, lookupResult=null, filters={q:"",kind:"all",status:"all"};
let modal=null; /* auth|staff|support|news|opp (edit) */
let toastTimer=null;
const ping=m=>{const el=document.createElement("div");el.className="toast";el.textContent=m;document.body.appendChild(el);clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.remove(),2800)};
const go=r=>{location.hash=r};
window.addEventListener("hashchange",()=>{route=location.hash||"#/";lookupResult=null;render();window.scrollTo(0,0)});
/* ---------- layout ---------- */
function tickerHtml(){
 if(!DB.settings.showAnn)return"";
 const items=DB.anns.filter(a=>a.on&&a.text.trim());
 if(!items.length)return"";
 const loop=[...items,...items].map(a=>`<span>${esc(a.text)}<span class="sep"> ✦ </span></span>`).join("");
 return `<div class="ticker" aria-hidden="true"><div class="ticker-track">${loop}</div></div>`;
}
function unseenNews(){
 let seen;try{seen=JSON.parse(localStorage.getItem("mada-news-seen"))||[]}catch(e){seen=[]}
 return DB.news.filter(n=>!seen.includes(n.id)).length;
}
function markNewsSeen(){
 const ids=DB.news.map(n=>n.id);let seen;try{seen=JSON.parse(localStorage.getItem("mada-news-seen"))||[]}catch(e){seen=[]}
 seen=[...new Set([...seen,...ids])];localStorage.setItem("mada-news-seen",JSON.stringify(seen));
}
function markSvg(size){return `<svg class="mark" width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" rx="16" fill="#2A2135"/><path d="M14 42c7-16 29-16 36 0" fill="none" stroke="#FBF9F3" stroke-width="3.2" stroke-linecap="round"/><circle cx="32" cy="24" r="3.2" fill="#7C5CBF"/></svg>`}
function topbarHtml(){
 const s=DB.session,un=unseenNews();
 return `<header class="top"><a class="brand" href="#/">${markSvg(34)} مَدى</a><nav class="top-links">
 <button class="icon-btn" data-act="news" aria-label="${esc(t("bell"))}">${ic.bell}${un?`<span class="nbadge">${un}</span>`:""}</button>
 <button class="icon-btn" data-act="lang" aria-label="${esc(t("meLang"))}">${L()==="ar"?"EN":"ع"}</button>
 ${s?`<a class="user-chip" href="#/me">${esc(s.name)}</a>`:`<button class="icon-btn" data-act="auth" aria-label="${esc(t("login"))}">${ic.user}</button>`}
 </nav></header>`;
}
function bnavHtml(){
 const p=route.split("#")[1]||"/";
 const items=[["#/",t("tabHome"),ic.home,p==="/"||p.startsWith("/opp")],["#/opportunities",t("tabOpp"),ic.grid,p.startsWith("/opportunities")],["#/ask",t("tabAsk"),ic.chat,p.startsWith("/ask")],["#/me",t("tabMe"),ic.user,p.startsWith("/me")]];
 return `<nav class="bnav">${items.map(i=>`<a href="${i[0]}" class="${i[3]?"on":""}">${i[2]}<span>${esc(i[1])}</span></a>`).join("")}</nav>`;
}
function footerHtml(){
 const s=DB.settings;
 return `<footer class="footer"><span>مَدى © ${new Date().getFullYear()}</span><nav><a href="${esc(s.channel)}" target="_blank" rel="noreferrer">${esc(L()==="ar"?"تابعنا":"Follow us")}</a><a href="${esc(s.tiktok)}" target="_blank" rel="noreferrer">TikTok</a></nav></footer>`;
}
/* ---------- shared renderers ---------- */
const kindLabel=i=>t(kindKey(i.type));
const seatsLabel=i=>i.seats&&i.seats!=="0"?i.seats:t("unlimited");
const statusTag=i=>`<span class="tag ${i.status}">${esc(t(i.status))}</span>`;
function tagsHtml(i){
 let h=`<span class="tag kind">${esc(kindLabel(i))}</span>${statusTag(i)}`;
 if(i.level)h+=`<span class="tag lvl">${esc(t("lvl"+i.level.charAt(0).toUpperCase()+i.level.slice(1)))}</span>`;
 if(i.pin)h+=`<span class="tag is-pin">${ic.pin} ${esc(t("pin"))}</span>`;
 return h;
}
function dlCountdown(i){
 if(!i.dl)return"";
 const d=new Date(i.dl);
 if(isNaN(d))return `<span class="dl-pill">${ic.clock} ${esc(i.dl)}</span>`;
 const diff=Math.ceil((d-Date.now())/864e5);
 if(diff<0)return `<span class="dl-pill bad">${ic.clock} ${esc(t("dlOver"))}</span>`;
 if(diff===0)return `<span class="dl-pill bad">${ic.clock} ${esc(t("lastDay"))}</span>`;
 if(diff<=3)return `<span class="dl-pill">${ic.clock} ${esc(t("closesIn"))} ${diff} ${esc(t("dayUnit"))}</span>`;
 return `<span class="dl-pill">${ic.clock} ${esc(d.toLocaleDateString(L()==="ar"?"ar-IQ":"en-GB"))}</span>`;
}
function factRows(i){
 const row=(icon,label,val)=>val?`<div class="fact-box"><div class="ft"><small>${esc(label)}</small><b>${esc(val)}</b></div>${icon}</div>`:"";
 const mode=t(i.mode==="online"?"modeOnline":i.mode==="person"?"modePerson":"modeHybrid");
 return `<div class="fact-list">
  ${row(ic.cal,t("date"),i.date)}
  ${row(ic.clock,t("time"),i.time)}
  ${row(ic.screen,t("mode"),mode)}
  ${row(ic.place,t("place"),i.place)}
  ${row(ic.users,t("seats"),seatsLabel(i))}
  ${row(ic.clock,t("dur"),i.dur)}
  ${row(ic.cap,t("level"),i.level?t("lvl"+i.level.charAt(0).toUpperCase()+i.level.slice(1)):"")}
 </div>`;
}
function oppCardHtml(i){
 const cover=i.cover?`<img class="opp-cover" src="${esc(i.cover)}" alt="" loading="lazy" onerror="this.style.display='none'">`:`<img class="opp-cover" src="${LOGO}" alt="" loading="lazy">`;
 const mode=t(i.mode==="online"?"modeOnline":i.mode==="person"?"modePerson":"modeHybrid");
 const cd=dlCountdown(i);
 return `<a class="opp-card" href="#/opp/${i.id}">${cover}<div class="opp-body"><div class="opp-tags">${tagsHtml(i)}</div><h3>${esc(i.title)}</h3><p class="sub">${esc(i.tagline)}</p><div class="card-meta"><span>${ic.cal}${esc(i.date||"—")}</span>${i.time?`<span>${ic.clock}${esc(i.time)}</span>`:""}<span>${ic.screen}${esc(mode)}</span></div>${cd?`<div class="cd-row">${cd}</div>`:""}</div></a>`;
}
/* ---------- pages ---------- */
function pageHome(){
 const pub=DB.opps.filter(i=>i.published);
 const open=pub.filter(i=>i.status==="open").length;
 const roles=Object.keys(T.ar.roles);
 const sugg=t("suggests");
 const latest=[...DB.news].sort((a,b)=>b.ts-a.ts).slice(0,3);
 return `
 <section class="hero">
  <h1>${esc(t("heroT"))}</h1>
  <p class="sub">${esc(t("heroP"))}</p>
  <div class="hero-cta"><a class="btn" href="#/opportunities">${esc(t("ctaOpp"))}</a><button class="btn2" data-act="staff">${esc(t("ctaTeam"))}</button></div>
  <div class="stats"><div class="stat"><b>${pub.length}</b><span>${esc(t("tabOpp"))}</span></div><div class="stat"><b>${open}</b><span>${esc(t("open"))}</span></div><div class="stat"><b>${DB.staff.length}</b><span>${esc(t("dashStaff"))}</span></div></div>
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("teamTitle"))}</h2></div>
  <p class="lede">${esc(t("teamP"))}</p>
  <div class="role-grid">${roles.map(r=>`<div class="role-pick"><b>${esc(t("roles")[r]||r)}</b><small>${esc(t("roleHints")[r]||"")}</small></div>`).join("")}</div>
  <div style="margin-top:1rem"><button class="btn" data-act="staff">${esc(t("staffBtn"))}</button></div>
  <p class="hint">${esc(t("staffP"))}</p>
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("lookupT"))}</h2></div>
  <p class="lede">${esc(t("lookupP"))}</p>
  <form id="lookupForm" class="two"><div class="field"><label for="lk">${esc(t("fPhone"))}</label><input id="lk" class="num" inputMode="tel" required></div><div class="field" style="align-self:end"><button class="btn2" style="width:100%">${esc(t("lookupBtn"))}</button></div></form>
  <div id="lookupOut"></div>
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("askTitle"))}</h2><a href="#/ask">${esc(t("askBtn"))} ←</a></div>
  <p class="lede">${esc(t("askP"))}</p>
  <div class="chips">${sugg.map(s=>`<a class="chip" href="#/ask">${esc(s)}</a>`).join("")}</div>
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("newsT"))}</h2><button class="btn2 btn-sm" data-act="news">${esc(t("newsAll"))}</button></div>
  ${latest.length?latest.map(n=>`<article class="news-card"><div class="sec-h"><h3>${esc(n.title)}</h3><span>${fmt(n.ts,L())}</span></div><p>${esc(n.text)}</p></article>`).join(""):`<div class="empty"><b>${esc(t("bellEmpty"))}</b></div>`}
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("supT"))}</h2></div>
  <p class="lede">${esc(t("supP"))}</p>
  <button class="btn2" data-act="support">${esc(t("supBtn"))}</button>
 </section>
 <section class="block">
  <div class="sec-h"><h2>${esc(t("aboutT"))}</h2></div>
  <p class="lede">${esc(t("aboutP"))}</p>
 </section>`;
}
function pageOpps(){
 let list=DB.opps.filter(i=>i.published);
 if(filters.q){const q=nrm(filters.q).toLowerCase();list=list.filter(i=>nrm(i.title+" "+i.tagline+" "+i.about).toLowerCase().includes(q))}
 if(filters.kind!=="all")list=list.filter(i=>i.type===filters.kind);
 if(filters.status!=="all")list=list.filter(i=>i.status===filters.status);
 list.sort((a,b)=>(b.pin?1:0)-(a.pin?1:0)||((b.ts||0)-(a.ts||0)));
 const kinds=[["all",t("all")],["ws",t("kindWs")],["vol",t("kindVol")],["grant",t("kindGrant")]];
 const st=[["all",t("all")],["open",t("open")],["soon",t("soon")],["closed",t("closed")]];
 return `<section class="block"><div class="sec-h"><h2>${esc(t("ctaOpp"))}</h2><span>${list.length}</span></div>
 <div class="filters"><div class="search">${ic.search}<input id="oppSearch" value="${esc(filters.q)}" placeholder="${esc(t("searchPh"))}"></div></div>
 <div class="chips">${kinds.map(k=>`<button class="chip ${filters.kind===k[0]?"on":""}" data-kind="${k[0]}">${esc(k[1])}</button>`).join("")}</div>
 <div class="chips">${st.map(k=>`<button class="chip ${filters.status===k[0]?"on":""}" data-status="${k[0]}">${esc(k[1])}</button>`).join("")}</div>
 ${list.length?`<div class="opp-list">${list.map(oppCardHtml).join("")}</div>`:`<div class="empty"><b>${esc(t("noOpps"))}</b><p>${esc(t("noOppsP"))}</p></div>`}
 </section>`;
}
function pageOppDetail(id){
 const i=DB.opps.find(o=>o.id===id);
 if(!i||!i.published)return `<section class="block"><div class="empty"><b>${esc(t("noOpps"))}</b></div></section>`;
 const open=i.status==="open";
 const learn=i.learn.filter(Boolean);
 const closedNote=L()==="ar"?(i.status==="soon"?"التقديم يفتح قريباً — تابع قناة مَدى لأول إعلان.":"التقديم مقفل حاليّاً."):(i.status==="soon"?"Applications open soon — follow the Mada channel for the first announcement.":"Applications are closed right now.");
 return `<section class="block">
  <div class="det-hero">
   <img class="det-cover" src="${esc(i.cover||LOGO)}" alt="">
   <div class="det-hero-body"><div class="opp-tags">${tagsHtml(i)}${dlCountdown(i)}</div><h1>${esc(i.title)}</h1><p class="sub">${esc(i.tagline)}</p></div>
  </div>
  ${factRows(i)}
  <h3>${esc(t("aboutOpp"))}</h3><p class="lede" style="white-space:pre-wrap">${esc(i.about)}</p>
  ${learn.length?`<h3>${esc(t("learn"))}</h3><ul class="learn-list">${learn.map(l=>`<li>${esc(l)}</li>`).join("")}</ul>`:""}
  <div class="det-cta">
   <small>${esc(t("ctaT"))}</small>
   <h3>${esc(t("ctaHead"))}</h3>
   <p>${esc(t("ctaHint"))}</p>
   ${i.link&&open?`<a class="btn btn-big" href="${esc(i.link)}" target="_blank" rel="noreferrer">${esc(t("externalApply"))} ↗</a>`:""}
   ${open&&!i.link?`<button class="btn btn-big" data-act="apply">${esc(t("ctaBtn"))}</button>`:""}
   ${!open?`<div class="closed-note">${statusTag(i)}<span>${esc(closedNote)}</span></div>`:""}
   <button class="btn2 btn-share" data-act="share">${ic.share} ${esc(t("share"))}</button>
  </div>
 </section>
 ${open&&!i.link?`<section class="block" id="applyBox" hidden>
  <div class="sec-h"><h2>${esc(t("qsTitle"))}</h2></div>
  <form id="applyForm">
   <div class="two"><div class="field"><label>${esc(t("fName"))}</label><input id="ap_name" placeholder="${esc(t("fNamePh"))}" required></div><div class="field"><label>${esc(t("fPhone"))}</label><input id="ap_phone" class="num" inputMode="tel" required></div></div>
   <div class="field"><label>${esc(t("fTg"))}</label><input id="ap_tg" placeholder="@username" required></div>
   ${(i.qs||[]).map((q,ix)=>`<div class="field"><label>${esc(q)}</label><textarea data-q="${ix}" required></textarea></div>`).join("")}
   <p class="hint">${esc(t("fNote"))}</p>
   <button class="btn" type="submit">${esc(t("fSend"))}</button>
  </form>
 </section>`:""}`;
}
function pageAsk(){
 return `<section class="block">
  <div class="sec-h"><h2>${esc(t("askTitle"))}</h2></div>
  <p class="lede">${esc(t("askP"))}</p>
  <div class="thread" id="thread"></div>
  <div class="chips" id="sugg">${t("suggests").map(s=>`<button class="chip" data-sg="${esc(s)}">${esc(s)}</button>`).join("")}</div>
  <div class="ask-bar"><textarea id="askInput" placeholder="${esc(t("askPh"))}" rows="1"></textarea><button class="btn" id="askSend">${esc(t("askSend"))}</button></div>
 </section>`;
}
function pageMe(){
 const s=DB.session;
 if(!s)return `<section class="block"><div class="sec-h"><h2>${esc(t("meTitle"))}</h2></div><div class="plain-card"><h2>${esc(t("meLoginT"))}</h2><p class="lede">${esc(t("meLoginSub"))}</p><button class="btn" data-act="auth" style="margin-top:.8rem">${esc(t("meJoin"))}</button></div></section>`;
 const rec=DB.users.find(u=>String(u.uid)===String(s.uid));
 const myApps=DB.apps.filter(a=>a.uid===s.uid);
 return `<section class="block">
  <div class="sec-h"><h2>${esc(t("meTitle"))}</h2></div>
  <div class="me-card"><h2>${esc(s.name)}</h2>${s.admin?`<span class="tag open">${esc(t("admin"))}</span>`:""}${rec?`<p class="hint">${esc(t("joinDate"))} ${fmt(rec.ts,L())}</p>`:""}</div>
  ${myApps.length?`<div class="block" style="box-shadow:none"><div class="sec-h"><h2>${esc(t("dashApps"))}</h2><span>${myApps.length}</span></div>${myApps.map(a=>`<div class="app-item"><h4>${esc(a.wsTitle)}</h4><span class="meta">${fmt(a.ts,L())}</span></div>`).join("")}</div>`:""}
  <div class="set-list">
   ${s.admin?`<a class="set-row" href="#/admin"><span style="display:inline-flex;align-items:center;gap:.45rem">${ic.dash} ${esc(t("meAdmin"))}</span></a>`:""}
   <button class="set-row" data-act="lang"><span>${esc(t("meLang"))}</span><small>${esc(t("langName"))}</small></button>
   <button class="set-row" data-act="logout">${esc(t("logout"))}</button>
  </div>
 </section>`;
}
function pageAdmin(){
 const s=DB.session;
 if(!s||!s.admin)return `<section class="block"><div class="sec-h"><h2>${esc(t("dashT"))}</h2></div><div class="plain-card"><h2>${esc(t("meLoginT"))}</h2><p class="lede">${esc(L()==="ar"?"هاي الصفحة للإدارة فقط. ادخل بحساب الأدمن.":"Admins only. Sign in with the admin account.")}</p><button class="btn" data-act="auth" style="margin-top:.8rem">${esc(t("meJoin"))}</button></div></section>`;
 const tabs=["staff","opps","apps","news","anns","sup","set"];
 return `<section class="block">
  <div class="sec-h"><h2>${esc(t("dashT"))}</h2></div>
  <div class="tabs">${tabs.map(x=>`<button class="chip ${adminTab===x?"on":""}" data-tab="${x}">${esc(t("dash"+x.charAt(0).toUpperCase()+x.slice(1)))}</button>`).join("")}</div>
  <div id="adminBody"></div>
 </section>`;
}
/* ---------- admin bodies ---------- */
const stTag=st=>`<span class="tag ${st==="accepted"?"open":st==="rejected"?"closed":"soon"}">${esc(t(st==="new"?"statusNew":st==="accepted"?"statusAccepted":"statusRejected"))}</span>`;
function adminBody(){
 const B=$("#adminBody");if(!B)return;
 if(adminTab==="staff"){
  B.innerHTML=DB.staff.length?[...DB.staff].reverse().map(s=>`<div class="app-item"><h4>${esc(s.name)} ${stTag(s.status)}</h4><span class="meta">${esc(s.age)} · ${esc(s.phone)} · @${esc(s.tg)} · ${esc(s.roles.map(r=>t("roles")[r]).join("، "))} · ${fmt(s.ts,L())}</span><p class="lede" style="margin:.4rem 0 0">${esc(s.idea)}</p><div class="actions">${s.status==="new"?`<button class="btn btn-ok btn-sm" data-acc="${s.id}">${esc(t("accept"))}</button><button class="btn btn-danger btn-sm" data-rej="${s.id}">${esc(t("reject"))}</button>`:""}<button class="btn2 btn-sm" data-copystaff="${s.id}">${esc(t("copyMsg"))}</button><button class="btn2 btn-sm" data-delstaff="${s.id}">${esc(t("del"))}</button></div></div>`).join(""):`<div class="empty"><b>${esc(t("noStaff"))}</b></div>`;
 }else if(adminTab==="opps"){
  B.innerHTML=`<button class="btn" id="newOpp" style="margin-bottom:.8rem">+ ${esc(t("addOpp"))}</button><div class="opp-list">${[...DB.opps].reverse().map(i=>`<div class="app-item"><h4>${esc(i.title)} ${i.published?`<span class="tag open">${esc(t("published"))}</span>`:`<span class="tag lvl">${esc(t("draft"))}</span>`} ${i.pin?`<span class="tag is-pin">${esc(t("pin"))}</span>`:""}</div><div class="actions"><button class="btn2 btn-sm" data-edit="${i.id}">${esc(L()==="ar"?"تعديل":"Edit")}</button><button class="btn btn-danger btn-sm" data-delopp="${i.id}">${esc(t("del"))}</button></div></div>`).join("")}</div>`;
 }else if(adminTab==="apps"){
  B.innerHTML=DB.apps.length?[...DB.apps].reverse().map(a=>`<div class="app-item"><h4>${esc(a.name)}</h4><span class="meta">${esc(a.wsTitle)} · ${esc(a.phone)} · @${esc(a.tg)} · ${fmt(a.ts,L())}</span><ul class="ans">${(a.answers||[]).map(x=>`<li><b>${esc(x.q)}</b><br>${esc(x.a)}</li>`).join("")}</ul><div class="actions"><button class="btn2 btn-sm" data-delapp="${a.id}">${esc(t("del"))}</button></div></div>`).join(""):`<div class="empty"><b>${esc(t("noApps"))}</b></div>`;
 }else if(adminTab==="news"){
  B.innerHTML=`<form id="newsForm"><div class="field"><input id="nw_title" placeholder="${esc(t("newsTitlePh"))}" required></div><div class="field"><textarea id="nw_text" placeholder="${esc(t("newsTextPh"))}" required></textarea></div><button class="btn">+ ${esc(t("add"))}</button></form>${DB.news.length?[...DB.news].reverse().map(n=>`<div class="news-card"><div class="sec-h"><h3>${esc(n.title)}</h3><span>${fmt(n.ts,L())}</span></div><p>${esc(n.text)}</p><div class="actions"><button class="btn2 btn-sm" data-delnews="${n.id}">${esc(t("del"))}</button></div></div>`).join(""):`<div class="empty"><b>${esc(t("noNews"))}</b></div>`}`;
 }else if(adminTab==="anns"){
  B.innerHTML=`<form id="annForm"><div class="field"><input id="an_text" placeholder="${esc(t("annPh"))}" required></div><button class="btn">+ ${esc(t("add"))}</button></form>${DB.anns.length?DB.anns.map(a=>`<div class="ann-item ${a.on?"on":""}"><span>${esc(a.text)}</span><div class="actions"><button class="btn2 btn-sm" data-tglann="${a.id}">${esc(a.on?t("hide"):t("show"))}</button><button class="btn btn-danger btn-sm" data-delann="${a.id}">${esc(t("del"))}</button></div></div>`).join(""):`<div class="empty"><b>${esc(t("noAnns"))}</b></div>`}`;
 }else if(adminTab==="sup"){
  B.innerHTML=DB.support.length?[...DB.support].reverse().map(m=>`<div class="sup-item"><h4>${esc(m.name)}</h4><span class="meta">${esc(m.contact||"—")} · ${fmt(m.ts,L())}</span><p class="lede" style="margin:.4rem 0 0">${esc(m.text)}</p><div class="actions"><button class="btn2 btn-sm" data-delsup="${m.id}">${esc(t("del"))}</button></div></div>`).join(""):`<div class="empty"><b>${esc(t("noSup"))}</b></div>`;
 }else{ /* set */
  const s=DB.settings;
  B.innerHTML=`<p class="note">${esc(t("setNote"))}</p>
  <form id="setForm">
   <div class="field"><label>${esc(t("sToken"))}</label><textarea class="mono" id="set_token">${esc(s.token)}</textarea></div>
   <div class="field"><label>${esc(t("sChat"))}</label><input id="set_chat" value="${esc(s.chatId)}" placeholder="-1001234567890"></div>
   <div class="two"><div class="field"><label>${esc(t("sCh"))}</label><input id="set_ch" value="${esc(s.channel)}"></div><div class="field"><label>${esc(t("sTt"))}</label><input id="set_tt" value="${esc(s.tiktok)}"></div></div>
   <div class="actions"><button class="btn" type="submit">${esc(t("saveSet"))}</button><button class="btn2" type="button" id="testTg">${esc(t("test"))}</button></div>
  </form>`;
 }
 bindAdmin();
}
function bindAdmin(){
 const B=$("#adminBody");if(!B)return;
 const q=(sel,fn)=>{B.querySelectorAll(sel).forEach(el=>el.addEventListener("click",fn))};
 q("[data-acc]",e=>{if(!confirm(t("confirmAccept")))return;const s=DB.staff.find(x=>x.id===e.currentTarget.dataset.acc);if(s){s.status="accepted";s.reply="";save();ping(t("acceptedDone"));render()}});
 q("[data-rej]",e=>{const s=DB.staff.find(x=>x.id===e.currentTarget.dataset.rej);if(s){s.status="rejected";save();render()}});
 q("[data-copystaff]",e=>{const s=DB.staff.find(x=>x.id===e.currentTarget.dataset.copystaff);if(s){const txt=`الف مبروك ${s.name}، تم قبولك بتيم مَدى وسوف يتم مراسلتك.`;navigator.clipboard?.writeText(txt);ping(t("copyOk"))}});
 q("[data-delstaff]",e=>{if(!confirm(t("delQ")))return;DB.staff=DB.staff.filter(x=>x.id!==e.currentTarget.dataset.delstaff);save();render()});
 q("[data-delapp]",e=>{if(!confirm(t("delQ")))return;DB.apps=DB.apps.filter(x=>x.id!==e.currentTarget.dataset.delapp);save();render()});
 q("[data-delnews]",e=>{if(!confirm(t("delQ")))return;DB.news=DB.news.filter(x=>x.id!==e.currentTarget.dataset.delnews);save();render()});
 q("[data-tglann]",e=>{const a=DB.anns.find(x=>x.id===e.currentTarget.dataset.tglann);if(a){a.on=!a.on;save();render()}});
 q("[data-delann]",e=>{if(!confirm(t("delQ")))return;DB.anns=DB.anns.filter(x=>x.id!==e.currentTarget.dataset.delann);save();render()});
 q("[data-delsup]",e=>{if(!confirm(t("delQ")))return;DB.support=DB.support.filter(x=>x.id!==e.currentTarget.dataset.delsup);save();render()});
 q("[data-delopp]",e=>{if(!confirm(t("delQ")))return;DB.opps=DB.opps.filter(x=>x.id!==e.currentTarget.dataset.delopp);save();render()});
 q("[data-edit]",e=>{editOppId=e.currentTarget.dataset.edit;openModal("opp")});
 const newB=$("#newOpp");if(newB)newB.addEventListener("click",()=>{editOppId=null;openModal("opp")});
 const nf=$("#newsForm");if(nf)nf.addEventListener("submit",e=>{e.preventDefault();DB.news.push({id:uid(),title:$("#nw_title").value.trim(),text:$("#nw_text").value.trim(),ts:Date.now()});save();ping(t("add"));render()});
 const af=$("#annForm");if(af)af.addEventListener("submit",e=>{e.preventDefault();DB.anns.push({id:uid(),text:$("#an_text").value.trim(),on:true,ts:Date.now()});save();render()});
 const sf=$("#setForm");if(sf)sf.addEventListener("submit",e=>{e.preventDefault();DB.settings.token=$("#set_token").value.trim();DB.settings.chatId=$("#set_chat").value.trim();DB.settings.channel=$("#set_ch").value.trim();DB.settings.tiktok=$("#set_tt").value.trim();save();ping(t("saveSet"))});
 const tt=$("#testTg");if(tt)tt.addEventListener("click",async()=>{const s=DB.settings;const ok=await tgSend(s.token,s.chatId,"مَدى — رسالة تجريبية ✅");ping(ok?t("testOk"):t("testFail"))});
}
/* ---------- modals ---------- */
function openModal(kind){modal=kind;render()}
function closeModal(){modal=null;render()}
function overlayHtml(inner){return `<div class="overlay" id="ovl"><div class="sheet" role="dialog" aria-modal="true">${inner}</div></div>`}
const sheetH=(title)=>`<div class="sheet-h"><h2>${esc(title)}</h2><button class="x" data-act="closeModal" aria-label="${esc(t("close"))}">×</button></div>`;
function authModalHtml(){
 return overlayHtml(sheetH(t("login"))+`
 <div class="seg"><button class="chip" data-mmode="log">${esc(t("logTab"))}</button><button class="chip" data-mmode="reg">${esc(t("regTab"))}</button></div>
 <form id="authForm">
  <div class="field"><label>${esc(t("uName"))}</label><input id="au_name" required></div>
  <div class="field"><label>${esc(t("uCode"))}</label><input id="au_code" type="password" required minlength="4"></div>
  <div class="field" id="au_code2w" hidden><label>${esc(t("uCode2"))}</label><input id="au_code2" type="password"></div>
  <p class="err" id="au_err"></p>
  <button class="btn" style="width:100%" id="au_go">${esc(t("uEnter"))}</button>
 </form>`).replace('data-mmode="log"','data-mmode="log" id="mmLog"').replace('data-mmode="reg"','data-mmode="reg" id="mmReg"');
}
function staffModalHtml(){
 const roles=Object.keys(T.ar.roles);
 return overlayHtml(sheetH(t("applyStaff"))+`
 <form id="staffForm">
  <div class="field"><label>${esc(t("staffName"))}</label><input id="st_name" required></div>
  <div class="two"><div class="field"><label>${esc(t("staffAge"))}</label><input id="st_age" class="num" inputMode="numeric" required></div><div class="field"><label>${esc(t("staffPhone"))}</label><input id="st_phone" class="num" inputMode="tel" required></div></div>
  <div class="field"><label>${esc(t("staffTg"))}</label><input id="st_tg" placeholder="@username" required></div>
  <div class="field"><label>${esc(t("rolesTitle"))}</label><div class="role-grid">${roles.map(r=>`<button type="button" class="role-pick" data-role="${r}"><b>${esc(t("roles")[r])}</b><small>${esc(t("roleHints")[r])}</small></button>`).join("")}</div></div>
  <div class="field"><label>${esc(t("staffIdea"))}</label><textarea id="st_idea" placeholder="${esc(t("staffIdeaPh"))}" required></textarea></div>
  <p class="err" id="st_err"></p>
  <p class="hint">${esc(t("fNote"))}</p>
  <button class="btn" style="width:100%" id="st_go">${esc(t("staffSend"))}</button>
 </form>`);
}
function supportModalHtml(){
 return overlayHtml(sheetH(t("supBtn"))+`
 <p class="lede">${esc(t("supP"))}</p>
 <form id="supForm">
  <div class="field"><label>${esc(t("supName"))}</label><input id="su_name" value="${esc(DB.session?.name||"")}" required></div>
  <div class="field"><label>${esc(t("supContact"))}</label><input id="su_ct"></div>
  <div class="field"><label>${esc(t("supMsg"))}</label><textarea id="su_msg" required></textarea></div>
  <button class="btn">${esc(t("supSend"))}</button>
 </form>`);
}
function newsModalHtml(){
 const list=[...DB.news].sort((a,b)=>b.ts-a.ts);
 return overlayHtml(sheetH(t("bell"))+(list.length?list.map(n=>`<article class="news-card"><div class="sec-h"><h3>${esc(n.title)}</h3><span>${fmt(n.ts,L())}</span></div><p>${esc(n.text)}</p></article>`).join(""):`<div class="empty"><b>${esc(t("bellEmpty"))}</b></div>`));
}
function oppModalHtml(){
 const i=editOppId?DB.opps.find(o=>o.id===editOppId):null;
 const v=k=>esc(i?i[k]??"":"");
 const blank={type:"ws",status:"open",mode:"online",level:""};
 const sel=(k,opts)=>{const cur=i?i[k]:blank[k];return opts.map(o=>`<option value="${o[0]}"${cur===o[0]?" selected":""}>${esc(o[1])}</option>`).join("")};
 return overlayHtml(sheetH(i?t("editOpp"):t("addOpp"))+`
 <form id="oppForm">
  <div class="field"><label>${esc(t("wType"))}</label><select id="op_type">${sel("type",[["ws",t("kindWs")],["vol",t("kindVol")],["grant",t("kindGrant")]])}</select></div>
  <div class="field"><label>${esc(t("wTitle"))}</label><input id="op_title" value="${v("title")}" required></div>
  <div class="field"><label>${esc(t("wTagline"))}</label><input id="op_tagline" value="${v("tagline")}"></div>
  <div class="field"><label>${esc(t("wAbout"))}</label><textarea id="op_about">${v("about")}</textarea></div>
  <div class="field"><label>${esc(t("wLearn"))}</label><textarea id="op_learn">${v("learn")}</textarea></div>
  <div class="two"><div class="field"><label>${esc(t("wDate"))}</label><input id="op_date" value="${v("date")}"></div><div class="field"><label>${esc(t("wTime"))}</label><input id="op_time" value="${v("time")}"></div></div>
  <div class="two"><div class="field"><label>${esc(t("wMode"))}</label><select id="op_mode">${sel("mode",[["online",t("modeOnline")],["person",t("modePerson")],["hybrid",t("modeHybrid")]])}</select></div><div class="field"><label>${esc(t("wStatus"))}</label><select id="op_status">${sel("status",[["open",t("open")],["soon",t("soon")],["closed",t("closed")]])}</select></div></div>
  <div class="two"><div class="field"><label>${esc(t("wPlace"))}</label><input id="op_place" value="${v("place")}"></div><div class="field"><label>${esc(t("wSeats"))}</label><input id="op_seats" class="num" value="${v("seats")}"></div></div>
  <div class="two"><div class="field"><label>${esc(t("wDur"))}</label><input id="op_dur" value="${v("dur")}"></div><div class="field"><label>${esc(t("wLevel"))}</label><select id="op_level">${sel("level",[["",t("all")],["beg",t("lvlBeg")],["mid",t("lvlMid")],["adv",t("lvlAdv")]])}</select></div></div>
  <div class="field"><label>${esc(t("wLink"))}</label><input id="op_link" value="${v("link")}" placeholder="https://…"></div>
  <div class="field"><label>${esc(t("wDl"))}</label><input id="op_dl" type="date" value="${v("dl")}"></div>
  <div class="field"><label>${esc(t("wCover"))}</label><input id="op_cover" value="${v("cover")}" placeholder="https://…jpg"></div>
  <div class="field"><label>${esc(t("wQs"))}</label><textarea id="op_qs">${esc(i?(i.qs||[]).join("\n"):"")}</textarea></div>
  <div class="actions"><label style="display:inline-flex;gap:.4rem;align-items:center;font-weight:600"><input type="checkbox" id="op_pub" ${i&&i.published?"checked":!i?"checked":""}> ${esc(t("wPub"))}</label><label style="display:inline-flex;gap:.4rem;align-items:center;font-weight:600"><input type="checkbox" id="op_pin" ${i&&i.pin?"checked":""}> ${esc(t("wPin"))}</label></div>
  <p class="err" id="op_err"></p>
  <div class="actions"><button class="btn" type="submit">${esc(t("save"))}</button><button class="btn2" type="button" data-act="closeModal">${esc(t("cancel"))}</button></div>
 </form>`);
}
function congratsHtml(){
 if(DB.session&&DB.session.admin)return"";
 const phone=DB.phone;
 const hit=DB.staff.find(s=>digits(s.phone)===digits(phone)&&s.status==="accepted"&&!DB.seenCongrats.includes(s.id));
 if(!hit)return"";
 return `<div class="overlay"><div class="sheet congrats">${markSvg(72)}<h2>${esc(t("congratsTitle"))}</h2><p class="quote">${esc(hit.reply||"الف مبروك تم قبولك وسوف يتم مراسلتك")}</p><div class="actions"><button class="btn" data-act="dismissCongrats" data-id="${hit.id}" style="width:100%">${esc(t("congratsOk"))}</button></div></div></div>`;
}
/* ---------- ask ---------- */
function renderThread(){
 const th=$("#thread");if(!th)return;
 th.innerHTML=DB.thread.length?DB.thread.map(m=>`<div class="bubble ${m.who}">${esc(m.text)}${m.src?`<br><span class="src">${esc(t("askSrc"))}</span>`:""}</div>`).join(""):`<div class="bubble bot">${esc(t("askHello"))}</div>`;
 th.scrollIntoView&&th.lastElementChild&&th.lastElementChild.scrollIntoView({block:"end"});
}
function askSubmit(){
 const inp=$("#askInput"),text=inp.value.trim();
 if(!text)return;
 DB.thread.push({who:"user",text});
 const lang=L();
 const ans=answerFromCatalog(text,toCatalog(DB.opps),lang);
 DB.thread.push({who:"bot",text:ans,src:true});
 save();inp.value="";renderThread();
}
/* ---------- apply ---------- */
async function applySubmit(opp){
 const name=$("#ap_name").value.trim(),phone=$("#ap_phone").value.trim(),tg=$("#ap_tg").value.trim().replace(/^@/,"");
 const qas=[...document.querySelectorAll("#applyForm textarea")].map(ta=>({q:opp.qs[Number(ta.dataset.q)]||"",a:ta.value.trim()}));
 if(!name||digits(phone).length<7||!tg||qas.some(x=>!x.a)){ping(t("needFields"));return}
 const row={id:uid(),wsId:opp.id,wsTitle:opp.title,name,phone,tg,answers:qas,ts:Date.now(),uid:DB.session?.uid??null};
 DB.apps.push(row);DB.phone=DB.phone||phone;save();
 const qs=opp.qs.map((q,i2)=>`${i2+1}. ${q}\n${qas[i2]?.a||"—"}`).join("\n\n");
 const text=`📌 تقديم جديد\n\nالفرصة: ${opp.title}\nالاسم: ${name}\nالهاتف: ${phone}\nتيليجرام: @${tg}\n\n${qs}`;
 const sent=await pushTelegram(text);
 ping(sent.ok?t("okSent"):t("okLocal"));
 $("#applyBox")&&($("#applyBox").hidden=true);
}
/* ---------- auth ---------- */
function authSubmit(mode){
 const name=$("#au_name").value.trim(),code=$("#au_code").value,code2=$("#au_code2")?.value||"";
 const err=m=>{$("#au_err").textContent=m};
 if(mode==="reg"){
  if(code.length<4)return err(t("errShort"));
  if(code!==code2)return err(t("errMatch"));
  const n=nrm(name);
  if(!n)return err(t("errShort"));
  if(n==="مدي"||n.toLowerCase()==="mada")return err(t("errReserved"));
  if(DB.users.some(u=>nrm(u.name)===n))return err(t("errExists"));
  const rec={name,codeHash:hash(code),uid:nextUid(),ts:Date.now()};
  DB.users.push(rec);DB.session={name,admin:false,uid:rec.uid};save();closeModal();ping(`${t("welcome")} ${name}`);
  return;
 }
 if(isOwnerLogin(name,code)){DB.session={name:"مَدى",admin:true,uid:"admin"};save();closeModal();go("#/admin");ping(`${t("welcome")} مَدى`);return}
 const u=DB.users.find(x=>nrm(x.name)===nrm(name));
 if(!u)return err(t("errNoUser"));
 if(u.codeHash!==hash(code))return err(t("errCode"));
 DB.session={name:u.name,admin:false,uid:u.uid};save();closeModal();ping(`${t("welcome")} ${u.name}`);
}
/* ---------- staff submit ---------- */
let pickedRoles=[];
async function staffSubmit(){
 const name=$("#st_name").value.trim(),age=Number($("#st_age").value),phone=$("#st_phone").value.trim(),tg=$("#st_tg").value.trim().replace(/^@/,""),idea=$("#st_idea").value.trim();
 const err=m=>{$("#st_err").textContent=m};
 const parts=nrm(name).split(" ").filter(p=>p.length>=2);
 if(parts.length<3)return err(t("staffNeedName"));
 if(!Number.isFinite(age)||age<14||age>70)return err(t("staffNeedAge"));
 if(digits(phone).length<8)return err(t("staffNeedPhone"));
 if(!/^[A-Za-z0-9_]{4,32}$/.test(tg))return err(t("staffNeedTg"));
 if(!pickedRoles.length)return err(t("staffNeedRole"));
 if(idea.length<8)return err(t("staffNeedIdea"));
 const row={id:uid(),name,age:String(age),phone,tg,roles:[...pickedRoles],idea,ts:Date.now(),status:"new",reply:""};
 DB.staff.push(row);DB.phone=phone;save();
 const labels=row.roles.map(r=>t("roles")[r]).join("، ");
 const text=`🆕 طلب انضمام لإدارة مَدى\n\nالاسم: ${row.name}\nالعمر: ${row.age}\nالهاتف: ${row.phone}\nتيليجرام: @${row.tg}\nالأقسام: ${labels}\n\nاقتراح لتطوير التيم:\n${row.idea}`;
 const sent=await pushTelegram(text);
 closeModal();ping(sent.ok?t("okSent"):t("okLocal"));
}
/* ---------- support submit ---------- */
async function supSubmit(){
 const name=$("#su_name").value.trim(),contact=$("#su_ct").value.trim(),text=$("#su_msg").value.trim();
 if(!name||!text)return;
 DB.support.push({id:uid(),name,contact,text,ts:Date.now()});save();
 const sent=await pushTelegram(`🆘 دعم مَدى\n\nالاسم: ${name}\nالتواصل: ${contact||"—"}\n\n${text}`);
 closeModal();ping(sent.ok?t("okSup"):t("okLocal"));
}
/* ---------- render ---------- */
function render(){
 document.documentElement.lang=L();
 document.documentElement.dir=L()==="ar"?"rtl":"ltr";
 const app=$("#app");
 const p=route.replace("#","");
 let body="";
 if(p==="/"||p==="")body=pageHome();
 else if(p.startsWith("/opportunities"))body=pageOpps();
 else if(p.startsWith("/opp/"))body=pageOppDetail(p.slice(5));
 else if(p.startsWith("/ask"))body=pageAsk();
 else if(p.startsWith("/me"))body=pageMe();
 else if(p.startsWith("/admin"))body=pageAdmin();
 else body=pageHome();
 app.innerHTML=tickerHtml()+`<div class="wrap">${topbarHtml()}${body}${p.startsWith("/admin")?"":footerHtml()}</div>${p.startsWith("/admin")?"":bnavHtml()}${modal==="auth"?authModalHtml():modal==="staff"?staffModalHtml():modal==="support"?supportModalHtml():modal==="news"?newsModalHtml():modal==="opp"?oppModalHtml():""}${congratsHtml()}`;
 bind();
 if(p.startsWith("/admin"))adminBody();
 if(p.startsWith("/ask")){renderThread()}
}
let authMode="log";
function bind(){
 /* global actions */
 $$("[data-act]").forEach(el=>el.addEventListener("click",e=>{
  const a=e.currentTarget.dataset.act;
  if(a==="auth"){authMode="log";openModal("auth")}
  else if(a==="lang"){DB.settings.lang=L()==="ar"?"en":"ar";save();render()}
  else if(a==="news"){markNewsSeen();openModal("news")}
  else if(a==="staff"){pickedRoles=[];openModal("staff")}
  else if(a==="support")openModal("support");
  else if(a==="apply"){const id=route.replace("#/opp/","");const b=$("#applyBox");if(b)b.hidden=false;b&&b.scrollIntoView({behavior:"smooth"})}
 else if(a==="share"){const url=location.href;if(navigator.share){navigator.share({title:"مَدى",url}).catch(()=>{})}else if(navigator.clipboard){navigator.clipboard.writeText(url).then(()=>ping(t("copied"))).catch(()=>ping(t("copied")))}else ping(t("copied"))}
  else if(a==="closeModal")closeModal();
  else if(a==="logout"){DB.session=null;save();ping(t("loggedOut"));go("#/")}
  else if(a==="dismissCongrats"){DB.seenCongrats.push(e.currentTarget.dataset.id);save();closeModal()}
 }));
 /* forms */
 const lk=$("#lookupForm");
 if(lk)lk.addEventListener("submit",e=>{e.preventDefault();const d=digits($("#lk").value);const hit=DB.staff.find(s=>digits(s.phone)===d);
  $("#lookupOut").innerHTML=hit?`<div class="staff-result"><b>${esc(hit.name)}</b>${stTag(hit.status)}<p class="hint">${esc(t("staffStatusT"))}</p></div>`:`<div class="staff-result"><b>${esc(t("staffNoFound"))}</b></div>`});
 const oppSearch=$("#oppSearch");
 if(oppSearch){oppSearch.addEventListener("input",e=>{filters.q=e.target.value;const pos=e.target.selectionStart;render();const ns=$("#oppSearch");if(ns){ns.focus();ns.setSelectionRange(pos,pos)}})}
 $$("[data-kind]").forEach(el=>el.addEventListener("click",()=>{filters.kind=el.dataset.kind;render()}));
 $$("[data-status]").forEach(el=>el.addEventListener("click",()=>{filters.status=el.dataset.status;render()}));
 const af=$("#applyForm");
 if(af)af.addEventListener("submit",e=>{e.preventDefault();const id=route.replace("#/opp/","");const opp=DB.opps.find(o=>o.id===id);if(opp)applySubmit(opp)});
 /* ask */
 const as=$("#askSend");
 if(as){as.addEventListener("click",askSubmit);$("#askInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();askSubmit()}})}
 $$("[data-sg]").forEach(el=>el.addEventListener("click",()=>{$("#askInput").value=el.dataset.sg;askSubmit()}));
 /* tabs */
 $$("[data-tab]").forEach(el=>el.addEventListener("click",()=>{adminTab=el.dataset.tab;render()}));
 /* modal internals */
 $$("[data-mmode]").forEach(el=>el.addEventListener("click",()=>{authMode=el.dataset.mmode;const log=authMode==="log";$("#au_code2w").hidden=log;$("#au_go").textContent=log?t("uEnter"):t("uCreate");$("#mmLog").classList.toggle("on",log);$("#mmReg").classList.toggle("on",!log)}));
 const auF=$("#authForm");
 if(auF)auF.addEventListener("submit",e=>{e.preventDefault();authSubmit(authMode)});
 $$("[data-role]").forEach(el=>el.addEventListener("click",()=>{const r=el.dataset.role;const on=pickedRoles.includes(r);if(on)pickedRoles=pickedRoles.filter(x=>x!==r);else pickedRoles.push(r);el.classList.toggle("on",!on)}));
 const stF=$("#staffForm");
 if(stF)stF.addEventListener("submit",e=>{e.preventDefault();staffSubmit()});
 const suF=$("#supForm");
 if(suF)suF.addEventListener("submit",e=>{e.preventDefault();supSubmit()});
 const ov=$("#ovl");
 if(ov)ov.addEventListener("click",e=>{if(e.target===ov)closeModal()});
 /* opp form */
 const opF=$("#oppForm");
 if(opF)opF.addEventListener("submit",e=>{
  e.preventDefault();
  const g=id=>$(id).value.trim();
  const data={type:g("#op_type"),title:g("#op_title"),tagline:g("#op_tagline"),about:g("#op_about"),learn:g("#op_learn").split("\n").map(x=>x.trim()).filter(Boolean),date:g("#op_date"),time:g("#op_time"),mode:g("#op_mode"),place:g("#op_place"),seats:g("#op_seats"),status:g("#op_status"),dur:g("#op_dur"),level:g("#op_level"),link:g("#op_link"),dl:g("#op_dl"),cover:g("#op_cover"),qs:g("#op_qs").split("\n").map(x=>x.trim()).filter(Boolean),published:$("#op_pub").checked,pin:$("#op_pin").checked};
  if(!data.title){$("#op_err").textContent=t("required");return}
  if(editOppId){const i=DB.opps.find(o=>o.id===editOppId);Object.assign(i,data);ping(t("oppSaved"))}
  else{data.id=uid();data.ts=Date.now();DB.opps.push(data);ping(t("oppAdded"))}
  save();editOppId=null;closeModal();
 });
}
render();
